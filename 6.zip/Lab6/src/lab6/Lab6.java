
package lab6;

import java.util.Scanner;


public class Lab6 {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        SeparateChainingHashMap table = new SeparateChainingHashMap(5);
            String stu_id;
            String course_id;
            String grade;
        System.out.print("Put\n");
        ////////////////////////////////////////////////
        do{
            System.out.print("StudentID :");
            stu_id = sc.nextLine();
            if(stu_id.equals(""))
                System.out.println();
            else if(stu_id.length()!=10)
                System.out.println("Incorrect StudentID\n");
            
            else{
                System.out.print("CourseID :");
                course_id = sc.nextLine();
               
                if(course_id.length()!=3)
                    System.out.println("Incorrect CourseID\n");
                else{
                    System.out.print("Grade :");
                    grade = sc.nextLine();
                    
                    if( grade.equals("A") || grade.equals("B") 
                        || grade.equals("C") || grade.equals("D") || grade.equals("F") )
                    {
                                StudentCourse s = new StudentCourse(stu_id,course_id);
                                table.put(s,grade);System.out.println();
                    }
                    else
                        System.out.println("Incorrect Grade\n");
                }
                
            }
        }
        while(!stu_id.equals(""));
        table.printTable();
        //////////////////////////////////
        
         System.out.print("Slove\n");
        do{
            System.out.print("StudentID :");
            stu_id = sc.nextLine();
            if(stu_id.equals(""))System.out.println();
            else if(stu_id.length()!=10)System.out.println("Invalid StudentID\n");
            else{
                System.out.print("CourseID :");
                course_id = sc.nextLine();
                StudentCourse s = new StudentCourse(stu_id, course_id);
                if(!table.containsKey(s))System.out.println("No information\n");
                else{
                    System.out.print("New Grade :");
                    grade = sc.nextLine();
                    if(grade.equals("A")||grade.equals("B")||grade.equals("C")||grade.equals("D")||grade.equals("F")){
                        table.put(s,grade);System.out.println();}
                    else System.out.println("Incorrect Grade\n");
                }
            }
        }
        while(!stu_id.equals(""));
        table.printTable();
        ///////////////////////////
        
        System.out.print("Delete\n");
        do{
            System.out.print("StudentID :");
            stu_id = sc.nextLine();
            if(stu_id.equals(""))System.out.println();
            else if(stu_id.length()!=10)System.out.println("Invalid StudentID\n");
            else{
                System.out.print("CourseID :");
                course_id = sc.nextLine();
                StudentCourse s = new StudentCourse(stu_id, course_id);
                if(!table.containsKey(s))System.out.println("No information\n");
                else{
                    table.remove(s);
                    System.out.println();
                }
            }
        }
        while(!stu_id.equals(""));
        table.printTable();
        
    }
    
}
