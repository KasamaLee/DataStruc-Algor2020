
package lab6;

public class SeparateChainingHashMap implements Map {
    //
    // static inner class
    private static class LinkedNode {
        Object key, value;
        LinkedNode next;
        LinkedNode(Object k, Object v, LinkedNode n) {
            key = k; value = v; next = n;
        }
    }
    //
    //
    
    private int size;
    private LinkedNode[] table;
    
    public SeparateChainingHashMap(int cap) {
        table = new LinkedNode[cap];
    }
    
    @Override
    public int size() { return size; }
    @Override
    public boolean isEmpty() { return size == 0; }
    @Override
    public Object get(Object key) {
        LinkedNode node = getNode(key);
        return node == null ? null : node.value;
    }
    @Override
    public boolean containsKey(Object key) {
        return getNode(key) != null;
    }
    private LinkedNode getNode(Object key) {
        LinkedNode cur = table[h(key)];
        while (cur != null && !cur.key.equals(key)) {
            cur = cur.next;
        }
        return cur;
    }
    private int h(Object x) {
        return Math.abs(x.hashCode()) % table.length;
    } 
    
    @Override
    public Object put(Object key, Object value) {
        LinkedNode node = getNode(key);
        Object oldValue = null;
        if (node != null) {
            oldValue = node.value;
            node.value = value;
        } 
        else {
            int h = h(key);
            table[h] = new LinkedNode(key, value, table[h]);
            ++size;
        }
        return oldValue;
    }
    
    @Override
    public void remove(Object key) {
        int h = h(key);
        if (table[h] == null) return;
        if (table[h].key.equals(key)) {
            table[h] = table[h].next; --size;
        } else {
            LinkedNode prev = table[h];
            while (prev.next != null && !prev.next.key.equals(key)) {
                prev = prev.next;
            }
            if (prev.next != null) {
                prev.next = prev.next.next; --size;
            }
        }
    }   
    
    public void printTable(){
        
        for(LinkedNode k : table){  
            if(k!=null) {
                System.out.println("Key: "+k.key);
                System.out.println("Value: "+k.value+"\n");
                 while(k.next!=null){
                    k=k.next;
                    System.out.println("Key: "+ k.key);
                    System.out.println("Value: "+k.value+"\n");
                }
            }
        }

    }
    
    
}
