package lab6;

public class StudentCourse {
    
    String stu_id;
    String course_id;
    
    public StudentCourse(String stu_id, String course_id) {
        this.stu_id = stu_id;
        this.course_id = course_id;

    }
    
    @Override
    public boolean equals(Object e){
        if(e instanceof StudentCourse) {
            StudentCourse ob = (StudentCourse) e;
            
            if( ob.course_id.equals(course_id)  &&  ob.stu_id.equals(stu_id) )
                return true;  
        }
        return false;   
    }
    
    @Override
    public int hashCode() {
        int hash = 0;
        String[] studentID  = stu_id.split("");
        for(String id:studentID){
            hash+=Integer.parseInt(id);
        }
        String[] courseID  = course_id.split("");
        for(String id:courseID){
            hash+=Integer.parseInt(id);
        }
        return hash;
    }
}
