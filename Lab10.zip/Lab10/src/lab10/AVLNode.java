/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab10;

/**
 *
 * @author TK
 */
public class AVLNode  extends BTNode {
    private int lefth, righth, weight;

 public AVLNode(Object o, BTNode l, BTNode r, int lh, int
rh, int w){
 super(o,l,r);
 lefth = lh;
 righth = rh;
 weight = w;
 }
 public int getLH(){
 return lefth;
 }
 public int getRH(){
 return righth;
 }
 public int getW(){
 return weight;
 }
 public void setLH(int l){
 lefth = l;
 }
 public void setRH(int r){
 righth = r;
 }
 public void setW(int w){
 weight = w;
 }
    
}
