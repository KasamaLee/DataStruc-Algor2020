package lab10;

public class Lab10 {

    public static void main(String[] args) {

        /*
        3. สร้างคลาสชื*อ Main เพื*อตรวจสอบการทํางานของ AVLTree โดยแสดงผลลัพธ์ที*ได้ออกมาทางจอภาพ
        ด้วย method printTree ด้วยtree traversal แบบ Preorder หลังจากที*ได้ดําเนินการต่าง ๆ ดงัน>ี
                    - เพิ่มข้อมูลชนิดเลขจํานวนเต็มซึ*งมีค่า 5, 7, 10, 12, 13, 15,25,และ28 ลงใน AVL Tree ตามลําดับ
        */
        
             AVLTree AVL = new AVLTree();
            Object ob1 = 5;
            Object ob2 = 7;
            Object ob3 = 10;
            Object ob4 = 12;
            Object ob5 = 13;
            Object ob6 = 15;
            Object ob7 = 25;
            Object ob8 = 28;

            AVL.addAVL(ob1);
            //AVL.printTree();
            AVL.addAVL(ob2);
            //AVL.printTree();
             AVL.addAVL(ob3);
            //AVL.printTree();
            AVL.addAVL(ob4);
            //AVL.printTree();
            AVL.addAVL(ob5);
           //AVL.printTree();
            AVL.addAVL(ob6);
            AVL.addAVL(ob7);
            AVL.addAVL(ob8);
            AVL.printTree();
 
           // AVL.removeAVL(ob4);
           // AVL.printTree();
           // AVL.removeAVL(ob6);
           // AVL.printTree();
    }
    
}
