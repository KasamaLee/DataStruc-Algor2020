package lab10;

            public class AVLTree extends BinarySearchTree{
                    public AVLTree(){
                    super();
         }
            public int max(int a,int b){
                    if (a < b)
                            return b;
                    else
                             return a;
            }

           public void updateHeight(AVLNode r){
                     AVLNode pLeft, pRight;
                    pRight = (AVLNode) r.getRight();
                    pLeft = (AVLNode) r.getLeft();
                    if (pLeft != null)
                            r.setLH(max(pLeft.getLH(),pLeft.getRH())+1);
                    else
                            r.setLH(0);
                    
                    if (pRight != null)
                            r.setRH(max(pRight.getLH(),pRight.getRH())+1);
                    else
                            r.setRH(0);
                    
                    r.setW(r.getLH()-r.getRH());
            }
         
//method adjustHeight ใช้พิจำรณำว่ำโหนดมีน ้ำหนักอยู่ในเกณฑ์ไหม ถ้ำไม่ก็ท ำกำรหมุนตำมเงื่อนไขที่อธิบำย
//ด้ำนบน
            public AVLNode adjustHeight(AVLNode start, AVLNode p, Stack s){
                    updateHeight(start);
                    if (Math.abs(start.getW())>1){
                              if (start.getW() > 0)
                                        if (p.getW() >= 0)
                                                start = singleRightRotate(start,p);
                                        else
                                        start = doubleRightRotate(start,p);
                             else
                                        if (p.getW() <= 0)
                                                start = singleLeftRotate(start,p);
                                        else
                                                start = doubleLeftRotate(start,p);
                                        updatePreNode(s,start);
                    }
                    return start;
            }
            
            public void updatePreNode(Stack s, AVLNode start){
                    AVLNode pre;
                    if (!s.isEmpty()){
                            pre = (AVLNode) s.peek();
                            if ((Integer) start.getData() < (Integer)pre.getData())
                                        pre.setLeft(start);
                            else
                                        pre.setRight(start);
                    }
                    else
                            root = start;
            }
            
//method singleRightRotate หมุนขวำ 1ครั้ง
            public AVLNode singleRightRotate(AVLNode start, AVLNode p){
                    start.setLeft(p.getRight());
                    p.setRight(start);
                    updateHeight(start);
                    updateHeight(p);
                    start = p;
                    return start;
            }

//method singleLeftRotate หมุนซ้ำย 1ครั้ง
            public AVLNode singleLeftRotate(AVLNode start, AVLNode p){
                    start.setRight(p.getLeft());
                    p.setLeft(start);
                    updateHeight(start);
                    updateHeight(p);
                    start = p;
                    return start;
            }
            
//method doubleRightRotate หมุนขวำ 2 ครั้ง
            public AVLNode doubleRightRotate(AVLNode start, AVLNode p){
                    AVLNode q;
                    q = (AVLNode) p.getRight();
                    p.setRight(q.getLeft());
                    start.setLeft(q.getRight());
                    q.setRight(start);
                    q.setLeft(p);
                    updateHeight(start);
                    updateHeight(p);
                    updateHeight(q);
                    start = q;
                    return start;
            }
            
//method doubleLeftRotate หมุนซ้ำย 2 ครั้ง
            public AVLNode doubleLeftRotate(AVLNode start, AVLNode p){
                    AVLNode q;
                    q = (AVLNode) p.getLeft();
                    p.setLeft(q.getRight());
                    start.setRight(q.getLeft());
                    q.setLeft(start);
                    q.setRight(p);
                    updateHeight(start);
                    updateHeight(p);
                    updateHeight(q);
                    start = q;
                    return start;
            }

            public void addAVL(Object e){
                    //เพิ่มโหนดเข้ำต้นไม้ AVL ตำมขั้นตอนที่อธิบำยไว้ในหัวข้อ 10.1.2
                     AVLNode start, t, p;
                    t = new AVLNode(e,null,null,0,0,0);
                    Stack s = new Stack();
                    if (root == null)
                            root = t;
                    else{
                            start = (AVLNode) root;
                            while (start != null){
                                        s.push(start);
                                        if ((Integer)t.getData()<(Integer) start.getData())
                                                start = (AVLNode) start.getLeft();
                                        else
                                                start = (AVLNode) start.getRight();
                            }
                            start = (AVLNode) s.pop();
                             if ((Integer) t.getData()<(Integer)start.getData())
                                        start.setLeft(t);
                            else
                                        start.setRight(t);
                            updateHeight(start);
                            p = start;
                            while (!s.isEmpty()){
                                        start = (AVLNode) s.pop();
                                        start = adjustHeight(start,p,s);
                                        p = start;
                            }
                    }
            }
/*ลบโหนดออกจำกต้นไม้ AVL หลังจำกลบโหนดโดยใช้ขั้นตอนของ Binary Search Tree ต้องเก็บโหนดที่ถูก
ผลกระทบหลังจำกกำรลบโหนดออกไป 1 โหนด นั่นคือเก็บโหนดที่น่ำสงสัยว่ำจะไม่เข้ำเกณฑ์เข้ำสู่ Stack แล้วพิจำรณำปรับทีละ
โหนดว่ำจะต้องหมุนหรือไม่ ถ้ำต้องหมุนจะต้องหมุนด้วยวิธีใดเพื่อให้โหนดที่สงสัยว่ำจะเกินเกณฑ์ ให้กลับเข้ำมำอยู่ในเกณฑ์ คล้ำยกับ
กระบวนกำร addAVL */
            
            public void removeAVL(Object e){
                    AVLNode start, pre, cur;
                    start = (AVLNode) root;
                    Stack s = new Stack();
                    pre = start;
                    boolean d = false;
                    
                     while((start != null) && (!d)){
                            s.push(start);
                            if (start.getData() == e)
                                        d = true;
                            else if((Integer) start.getData() > (Integer) e){
                                        pre = start;
                                        start = (AVLNode) start.getLeft();
                            }
                            else{
                                        pre = start;
                                        start = (AVLNode) start.getRight();
                            }
                    }
                     
                    if(start == null) return;
                    if ((start.getLeft() == null) && (start.getRight() == null))
                            if(start == root)
                                        root = null;
                            else
                                        if(pre.getLeft() == start)
                                                pre.setLeft(null);
                                        else
                                                pre.setRight(null);
                    else if ((start.getLeft() != null) && (start.getRight() != null)){
                            pre = start;
                            cur = (AVLNode) start.getLeft();
                            s.push(cur);
                            
                             while (cur.getRight() != null){
                                        pre = cur;
                                        s.push(cur);
                                        cur = (AVLNode) cur.getRight();
                            }
                            start.setData(cur.getData());
                            
                            if (pre == start)
                                        pre.setLeft(cur.getLeft());
                            else
                                        pre.setRight(cur.getLeft());
                            }
                    else
                            if(start.getLeft() != null)
                                        if(start == root)
                                                root = start.getLeft();
                                        else
                                                if(pre.getLeft() == start)
                                                        pre.setLeft(start.getLeft());
                                                else
                                                        pre.setRight(start.getLeft());
                            else
                                        if(start == root)
                                                root = start.getRight();
                                        else
                                                if(pre.getRight() == start)
                                                        pre.setRight(start.getRight());
                                                else
                                                        pre.setLeft(start.getRight());
                                                //size --;
                    s.pop();
                     AVLNode p;
                     while (!s.isEmpty()){
                            start = (AVLNode) s.pop();
                            updateHeight((AVLNode) start);
                            if (Math.abs(start.getW()) > 1){
                                        if (start.getLH() < start.getRH())
                                                p = (AVLNode) start.getRight();
                                        else
                                                p = (AVLNode) start.getLeft();
                                        adjustHeight(start,p,s);
                            }
                    }
            }
            
            
}
