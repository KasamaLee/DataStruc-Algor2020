/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab10;

//ทั้งกำรเพิ่มโหนดหรือลบโหนด ใน ต้นไม้ AVL ต้องใช้ Stack มำช่วย
public class Stack {
 private Object[] s;
 private int top;
 public Stack(){
 s = new Object[10];
 top = -1;
 }
 public int size(){
 return top+1;
 }
 public void push(Object o){
 if(top == s.length-1)
 s = doubleSize(s);
 top++;
 s[top] = o;
 }
 private static Object[] doubleSize(Object[] origin){
 Object[] temp = new Object[origin.length*2];
 System.arraycopy(origin,0,temp,0,origin.length);
 return temp;
 }
 public Object pop(){
 if(isEmpty()) return null;
 Object e = s[top];
 top--;
 return e;
 }
 public boolean isEmpty(){
 return top == -1;
 }
 public void printStack(){
 while (!(isEmpty())){
 System.out.println(pop());
 }
 }
 public Object peek(){
 Object e = s[top];
 return e;
 }
}
