package lab2;
import java.util.Scanner;

public class Lab2 {

    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        String name ;
        
        //Nomination for A
        System.out.println("Nomination for A: ");
        LinkedSet a = new LinkedSet();
        name = sc.nextLine();
        while(!name.equals("") ) {
            a.add(name);
            name = sc.nextLine();
        }
        //end of Nomination for A
        
        //Nomination for B
        LinkedSet b = new LinkedSet();
        System.out.println("Nomination for B: ");
        name = sc.nextLine();
        while(!name.equals("") ) {
            b.add(name);
            name = sc.nextLine();
        }
        //end of Nomination for B
         
        //หน้าOutput
        System.out.println( "Output:" );
        System.out.println( a.size() + "names nominated for A" );
        System.out.println( b.size() + "names nominated for B" );
        System.out.println( a.intersection(b).size() + "names nominated for both A and B" );
        System.out.println( a.union(b).size() + "names nominated for A or B" );
        
    }
    
}
