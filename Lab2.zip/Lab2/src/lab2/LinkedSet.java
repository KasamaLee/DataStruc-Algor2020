package lab2;

public class LinkedSet extends LinkedCollection {

    public LinkedSet() {
        super();
    }
    
    @Override 
    public void add(Object e) {
        if(!contains(e)) {
            super.add(e);
        }
    }
    /*
    public LinkedSet clone(LinkedSet b) {
        //ไม่สามารถเข้าถึงตัวแปร element และ next ได้
        //ให้แปลง LinkedList เป็น ArrayList ก่อน แล้วค่อยดำเนินการทางเซตโดยใช้เมธอด add() สร้าง LinkedSet ใหม่ขึ้นมา
        LinkedSet b2 = b ;
        LinkedSet dupSet = new LinkedSet();
        while(b2!=null) {
            dupSet.add(b.next.element);
            b2 = b2.next ;
        }
        return (LinkedSet) dupSet;
   }
    */
    public LinkedSet union(LinkedSet b) {
        Object[] aa  = super.toArray();
        Object[] bb = b.toArray();
        LinkedSet unionSet = new LinkedSet();
        for(Object e : aa) {
            unionSet.add(e);
        }
        for(Object e : bb) {
            unionSet.add(e);
        }
        return unionSet ;
    }
    
    public LinkedSet intersection(LinkedSet b) {
        Object[] bb = b.toArray();
        LinkedSet intersectSet = new LinkedSet();
        for (Object e : bb) {
            if ( super.contains(e) ) intersectSet.add(e);         
        }
        return intersectSet ;
    }
    
}
