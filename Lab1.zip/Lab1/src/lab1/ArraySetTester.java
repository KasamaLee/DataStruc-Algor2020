
package lab1;

import java.util.Arrays;

/**
 *
 * @author TK
 */
public class ArraySetTester {

    public static void main(String[] args) {
        
        //ArrayCollection a = new ArrayCollection(2);
        ArraySet a = new ArraySet(2);
        a.add("Kelvin");
        a.add("Bob");
        a.add("Steward");
        System.out.println("sizeของอาเรย์ : " + a.size());
        Object[] aa = a.toArray();
        System.out.println(Arrays.toString(aa));
        
        ArraySet b = new ArraySet(0);
        b.add("Kelvin");
        b.add("Steward");
        b.add("Gru");
        b.add("Bob");
        
        System.out.println("sizeของอาเรย์ : " + b.size());
        Object[] bb = b.toArray();
        System.out.println(Arrays.toString(bb));
        
        a.Union(b);
        a.Intersection(b);
        a.Equals(b);
     }
    
}
