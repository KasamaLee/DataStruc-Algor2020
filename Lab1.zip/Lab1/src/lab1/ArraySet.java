package lab1;
import java.util.Arrays;

public class ArraySet extends ArrayCollection {
    //แอตทริบิ้วของคลาสแม่เป็นprivate คลาสลูกไม่สามารถเข้าถึงได้
    //จึงต้องประกาศแอตทริบิ้วด้วย
    //private Object[] elementData;
    //private int size;

    public ArraySet(int c) {
        super(c);
    }
    
    @Override
    public void add(Object e) {
        
        if(e == null) throw new IllegalArgumentException();
        if( !super.contains(e) ) {
            super.add(e);
        }
    }
    
    public void Union(ArraySet b) {
        Object[] aa  = super.toArray();
        Object[] bb = b.toArray();
         //System.out.println("IN METHOD อาเรย์bb: " +Arrays.toString(bb));
         //System.out.println(super.size()); 
         //System.out.println("IN METHOD อาเรย์aa: " + Arrays.toString(aa));
        ArraySet union = new ArraySet(super.size());
         //System.out.println(super.size()); //ขนาดa
         for( int i=0 ; i<super.size() ; i++ ) {
            union.add(aa[i]);
            //System.out.println("อาเรย์union  : " + Arrays.toString(aa));
         }
         for(int i=0 ; i<b.size() ; i++ ) {
             if( !union.contains(bb[i]) ) {
                    union.add(bb[i]);
             }
         }
         System.out.println( "ผลการยูเนียน : " + Arrays.toString(union.toArray()));  
    }
    
     public void Intersection(ArraySet b ) {
        //Object[] aa  = super.toArray();
        Object[] bb = b.toArray();
        ArrayCollection inTerSect = new ArrayCollection(super.size());
        for (int i=0; i<b.size(); i++){
               if(super.contains(bb[i])) {
                   // เพิ่มสมาชิกลงในinTerSect เมื่อ bb[i] สามารถหาเจอใน Object[] aa
                   inTerSect.add(bb[i]);
                   //System.out.println("ผลการอินเตอร์เซครอบที่ " + i + " คือ " + Arrays.toString( inTerSect.toArray()) );  
               }
        }
        System.out.println("ผลการอินเตอร์เซค : " + Arrays.toString( inTerSect.toArray()) );  
      }
     
      public void Equals(ArraySet b) {
        //Object[] aa  = super.toArray();
        Object[] bb = b.toArray();
        
        //ตรวจสอบขนาดของเซตเท่ากันหรือไม่
        if(b.size() == super.size()) {
             for (int i=0; i<b.size(); i++) {
                if(!super.contains(bb[i])) System.out.println("การเท่ากันของเซต : " + "Not Equals");
             }
             System.out.println("การเท่ากันของเซต : " + "Equals");  
        } 
        else {                                      
            System.out.println("การเท่ากันของเซต : " + "Not Equals");  
        }
      }

} 
