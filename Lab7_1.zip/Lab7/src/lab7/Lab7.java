package lab7;

import java.util.Arrays;
import java.util.Scanner;

public class Lab7 {
    

    public static void main(String[] args) {
        
        SortCollection2 sort_a = new SortCollection2();

 
        Scanner sc = new Scanner(System.in);
        Object num ;
        
        do{
            System.out.println("Add Value: ");
            num  = sc.nextLine();
            MyNode a = new MyNode(num,null);
            sort_a.add(a);
        }  
        while (!num.equals(""));
        
       
      
    
         do{
            System.out.println("Remove Value: ");
            num  = sc.nextLine();
            MyNode a = new MyNode(num,null);
            sort_a.remove(a);
         }  
         while (!num.equals(""));

         Object[] c = sort_a.printList();
       System.out.print(Arrays.toString(c));
   
    
    }
}


/*
         static  void printList(SortCollection2 sort_a) {

                   Object arr[] = new Object[sort_a.size()] ;
                   for (MyNode a : sort_a ) {
                            
                  }
                   
          }
       */
    
