
package lab7;

public interface SortCollection {
    void add(MyNode e);
    void remove(MyNode e);
    boolean contain(MyNode e);
    boolean isEmpty();
    int size();
}
