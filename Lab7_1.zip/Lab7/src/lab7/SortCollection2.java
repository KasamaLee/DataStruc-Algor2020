package lab7;

import static java.lang.String.valueOf;
import java.util.NoSuchElementException;

/*
NO_1
*/

public  class SortCollection2 implements SortCollection{
    
    private MyNode head ;
    private int size ;

    public SortCollection2() {
          head = new MyNode(null,null);
          size = 0 ;
    }
        
    @Override
    public boolean isEmpty() {
        // return size==0 ;
        return head.getNext() != null;
    }
    
    @Override
    public int size(){
           // return size ;
           int size = 0 ;
           MyNode node = head ;
            while( node.getNext()!=null ){
                size++ ;
            }
            return size ;
    }
    
    @Override
    public void add(MyNode a){
        if(contain(a)) return ; //(b == c)
       if(isEmpty()) {
              head.setNext(a);
         }
        else{
             int count = 0 ;
              MyNode checkingData = new MyNode(a,null);
              //checkingData.setNext(a);
             MyNode node = head ;
             for(int i=0 ; i<size() ; i++){
                int n = (int) node.getData();
                int c = (int)checkingData.getData();
                if(n > c)
                    node = node.getNext();
                else    
                    
                    head.setNext(checkingData);
                    count++ ;
            } 
        }    
    }

    
    @Override
    public void remove(MyNode a) {
        
          if(!contain(a))  return  ; // ลิสว่าง หรือ ไม่มีข้อมูลตัวนี้ในลิส
          MyNode checkingData = new MyNode(a,null);
          int count = 0 ;
          for(int i=0 ; i<size() ; i++) {
                   MyNode node = head ;
                   if( node.getNext().getData() == checkingData.getData() ) {
                            node = node.getNext().getNext() ;
                            count++ ;
                   }
                   else node = node.getNext();
          }
    }
    
    @Override
    public boolean contain(MyNode a){
          if(isEmpty()) return false ;       
          else {
                   MyNode checkData = new MyNode(a,null);
                   //checkData.setNext(a);
                   for(int i=0 ; i<size() ; i++){ 
                            MyNode node = head ;
                            //int i = Integer.valueOf((String) object);
                            int n = (int) node.getData();
                            int c = (int)checkData.getData();
                            
                            if (n == c)       return true ;
                            //else if (n < c) return false ;
                            else  node = node.getNext();   //(b > c)      
                   }
          //หมุนครบแล้ว หาไม่เจอ หรือคือ ไม่เจอตัวซ้ำ
          return false ;
          }    
    }

    public  Object[]  printList() {
         Object arr[] = new Object[size()] ;
         // if(isEmpty()) throw new NoSuchElementException();
          MyNode node =  head;
          //String dis = "" ;
          for (int i =0 ; i <size() ; i++ ) {
                            arr[i] = node.getNext().getData();
                    //        dis += (String)node.getData() ;
                            //node = node.getNext();
          }
         // System.out.println("lab7.SortCollection2.printList()");
         // System.out.println(dis );
         return arr ;
    }
    
}
