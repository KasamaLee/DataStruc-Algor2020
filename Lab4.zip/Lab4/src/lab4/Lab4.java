package lab4;
import java.util.Scanner;

public class Lab4 {

    public static void main(String[] args) {
        // TODO code application logic here
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter Postfix Expression: ");
        String postfixStr = sc.nextLine();
        Postfix pos1 = new Postfix(postfixStr) ;
         System.out.println( "Eval Result: "+pos1.eval() );
         System.out.println( "Infix Expression: "+pos1.toInfix() );
    }
    
}
