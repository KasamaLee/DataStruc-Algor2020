package lab4;

public class Postfix {
    
    private String[] tokens;
    
    Postfix( String postfixStr ){
        //tokens = new String[]{}; 
        tokens = postfixStr.split(" "); //แยกสตริงด้วยspaceBar เก็บในลิสทีละตัว
    }
    
    public Boolean isOp( String x ){ //เช็คเป็นโอเปอเรเตอร์Y/N 
        String operator = "+-*/^";
        return operator.contains(x);
            /*
            for (String e : operator) {
                if (op.equals(e)) 
                    return true ;     
            } 
        return false ; */
    }
    
    public float apply( float a, float b, String object ){ //เมื่อเจอโอเปเรเตอร์ ให้คืนค่าคิดเลขออกไป
        switch (object) {
            case "+" : return b + a ; 
            case "-" : return b - a;  
            case "*" : return b * a;    
            case "/" : return b / a;
            case "^" : return (float) Math.pow(a, b);
            default: return 0;
                }
    }
    
    public float eval(){
        Stack num = new ArrayStack() ;
        for (String x : tokens) {
            if( !isOp(x) ){
                num.push( Float.parseFloat(x) );  //เอาเข้าสแตกเป็นสตริง
            }
            else {
                float num1 =  (float) num.pop() ;
                float num2 =  (float) num.pop()  ;
                num.push( apply(num1, num2, x) );
            }
        }
        return (float) num.pop()  ;
    }

    public String toInfix(){
        Stack inFix = new ArrayStack() ;
        String inFixStr = "" ;
        for(String x : tokens){
            if( !isOp(x) ) inFix.push(x); //สตริง
            else{
                String num2 = (String) inFix.pop();
                String num1 = (String) inFix.pop();
                String sum1 =  "(" + num1 + x + num2 + ")" ;
                inFix.push(sum1);
            }
        } 
        for(int i = 0 ; i<inFix.size() ; i++){
            inFixStr += inFix.pop();
        }
        return inFixStr ;
    }
    
    
}
