package lab4;

public class ArrayStack implements Stack {
  private Object[] elementData = new Object[1];
  private int size=0;
  
  public boolean isEmpty() {  
      return size==0;    
  }
  public int size() {
      return size;
  }
  public void push(Object e) {  
    if (size == elementData.length) {
      Object[] arr = new Object[2*elementData.length];
      for (int i=0; i<size; i++) arr[i] = elementData[i];
      elementData = arr;
    }
    elementData[size++] = e;
  }
  public Object peek() {
    if (isEmpty())      throw new IllegalStateException();
    return elementData[size-1];
  }
  public Object pop()  {
    Object e = peek();    elementData[--size] = null;
    return e;
  }

}
