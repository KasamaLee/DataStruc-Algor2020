
package lab4;

/**
 *
 * @author usci
 */
public interface Stack {
  public boolean isEmpty();  // is stack empty?
  public int size();         // get the size of stack
  public void push(Object e);// add e on top of stack
  public Object pop();       // get and remove the topmost value in stack
  public Object peek();      // get the topmost value in stack
}