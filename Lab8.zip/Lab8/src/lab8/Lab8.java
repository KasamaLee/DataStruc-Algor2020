package lab8;

/**
 *
 * @author TK
 */
public class Lab8 {

    public static void main(String[] args) {
        // TODO code application logic here
         BinarySearchTree BST = new BinarySearchTree();
        BST.add(9);
        BST.add(2);
        BST.add(12);
        BST.add(1);
        BST.add(5);
        BST.add(10);
        BST.add(15);
        System.out.println("Count node : " + BST.nnodes() );
        System.out.println("Min : " + BST.getMin() ); 
        System.out.println("Max : " + BST.getMax() ); 
        System.out.println("Contain 12 : " + BST.contains(12) ); 
        System.out.println("Contain 20 : " + BST.contains(20) ); 
        BST.printTree();  
    }
}
    

