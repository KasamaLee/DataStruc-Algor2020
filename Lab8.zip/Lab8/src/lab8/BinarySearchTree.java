package lab8;

public class BinarySearchTree {
    private BTNode root;
    private int size;
    
    public BinarySearchTree() {
        root = null;
        size = 0;
    }
    
    public int size() {
        return size;
    }
    
    public boolean isEmpty() {
        return root == null;
    }
    
    public void add(Object e) {
        if (e == null) return;
        BTNode start = root;
        BTNode pre = null;
        BTNode tmp = new BTNode(e,null,null);
        int value = (Integer) e;
        if (root == null) {
            root = tmp;
            size++;
        }
        else {
            while (start != null) {
                pre = start;
                int BTNode = (Integer) start.getData();
                if (BTNode == value) {
                    System.out.println("Object : "+ e +" has existed in the tree.");
                    start = null;
                    return;
                }
                else {
                    if (BTNode > value) start = start.getLeft();
                    else start = start.getRight();
                }
            }
            int curNode = (Integer) pre.getData();
            if (curNode > value) {
                pre.setLeft(tmp);
                size++;
            }
            else if (curNode < value) {
                pre.setRight(tmp);
                size++;
            }
        }
    }
    
    public boolean contains(Object e) {
        BTNode start;
        start = root;
        int value = (Integer) e;
        while (start != null) {
            int BTNode = (Integer) start.getData();
            if (BTNode == value) return true;
            else {
                if (BTNode > value) start = start.getLeft();
                else {
                    if (BTNode > value) start = start.getLeft();
                    else start = start.getRight();
                }
            }
        }
        return false;
    }
    
    public Object getMin() {
        BTNode start = root;
        if (start == null) return null;
        while (start.getLeft() != null) {
            start = start.getLeft();
        }
        return start.getData();
    }
    
    public Object getMax() {
        BTNode start = root;
        if (start == null) return null;
        while (start.getRight() != null) {
            start = start.getRight();
        }
        return start.getData();
    }
    
    private int nnodes(BTNode r) {
        if (r == null) return 0;
        return 1+ nnodes(r.getLeft()) + nnodes(r.getRight());
    }
    
    public int nnodes() {
        BTNode r = root;
        return nnodes(r);
    }
    
    public void inOrder(BTNode r) {
        if (r != null) {
            inOrder(r.getLeft());
            System.out.print(r.getData() + "  ");
            inOrder(r.getRight());
        }
    }
    
    public void printTree() {
        BTNode r = root;
        if (isEmpty()) System.out.println("Tree is empty.");
        System.out.print("Inorder : ");
        inOrder(r);
    }

}