package lab12;

public class QuickSort {

    public QuickSort (){        }
    
    public void quickSort(int[]a,int first,int last){
            int splitpoint;
            if(first<last){
                    splitpoint=split(a,first,last);
                    quickSort(a,first,splitpoint);
                    quickSort(a,splitpoint+2,last);
            }
     }
    
    public int split(int[] a,int first,int last){
           int pivot,saveLast,tmp;
            boolean lessThanPivot , greaterPivot;
            pivot = a[last];
            saveLast=last;
            last--;
            do{
                    lessThanPivot=true;
                     while((first<=last)&&(lessThanPivot)) {
                              if(a[first]<pivot)
                                      lessThanPivot=false;
                              else
                                      first++;
                      }
                    greaterPivot=true;
                    while((first<=last)&&(greaterPivot)) {
                             if(pivot<a[last])
                                       greaterPivot=false;
                             else 
                                        last--;
                   }
                   if(first<last){
                               tmp=a[first];
                               a[first]=a[last];
                               a[last]=tmp;
                               first++;
                               last--;
                   }
           }  while(first<=last);
           tmp=a[saveLast];
           a[saveLast]=a[first];
           a[first]=tmp;
           return last;
    }
    
    public void printArray(int[] a,int size){
          int i;
          for(i=0;i<size;i++){
                    System.out.print(a[i]+" ");  
          }
        
    }
    
 }