package lab12;

public class LAB12 {

    public static void main(String[] args) {
        // TODO code application logic here
        
          int[] arr = {15,9,7,16,31,2,20,25,17,12};
          QuickSort q = new QuickSort();
          q.quickSort(arr, 0, arr.length-1);
          System.out.print("Quick Sort : ");
          q.printArray(arr, arr.length);
        
          int[] a = {5,2,12,9,1,8,7,18};
          MergeSort m = new MergeSort();
          m.mergeSort(a, 0, a.length-1);
          System.out.print("\nMerge Sort : ");
          m.printArray(a, a.length);
    }
    
}
