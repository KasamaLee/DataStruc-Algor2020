package lab12;

public class MergeSort {
    
    public MergeSort () {   }
    
    public void mergeSort(int a[], int first, int last) {
          int mid;
          if (first < last) {
                    mid = (first+last) / 2;
                    mergeSort (a, first, mid);
                    mergeSort (a, mid+1, last);
                    merge (a, first, mid, mid+1, last);
          }
    }
    
    public void merge (int a[], int leftF, int leftL, int rightF, int rightL) {
          int [] templist = new int[a.length];
           int index, saveLeftF;
           index = leftF;
           saveLeftF = leftF;
            while ((leftF <= leftL) && rightF <= rightL) {
                    if (a[leftF] > a[rightF]) {
                              templist[index] = a[leftF];
                              leftF = leftF+1;
                    }
                    else {
                             templist[index] = a[rightF];
                             rightF = rightF+1;
                    }
                    index++;
          }
           while (leftF <= leftL) {
                     templist[index] = a[leftF];
                     leftF++;
                     index++;
          }
           while (rightF <= rightL) {
                     templist[index] = a[rightF];
                     rightF++;
                     index++;
          }
           for (index = saveLeftF; index <= rightL; index++) {
                    a[index] = templist[index];
           }
    }
    
    public void printArray(int[] a,int size){
           int i;
           for(i=0;i<size;i++){
                    System.out.print(a[i]+ " "); 
          }
    }
    
}

