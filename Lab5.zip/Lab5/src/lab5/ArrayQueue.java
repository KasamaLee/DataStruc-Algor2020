package lab5;
import java.util.Arrays;
import java.util.NoSuchElementException;

public class ArrayQueue implements Queue {
    
  private Object[] elementData;
  private int size;
  private int front;

  public ArrayQueue(int cap) {
    elementData = new Object[cap];
    size = front = 0;
  }
  
  @Override
  public boolean isEmpty() {
    return size == 0;
  }
  
  @Override
  public int size() {
    return size;
  }
  
  @Override
  public void enqueue(Object e) {
    if (size == elementData.length) {
      Object[] a = new Object[2 * elementData.length];
      for (int i = 0, j = front; i < size;
           i++, j = (j+1)%elementData.length)
        a[i] = elementData[j];
      front = 0; elementData = a;
    }
    int b = (front + size) % elementData.length;
    elementData[b] = e; 
    size++;
  }
  
  @Override
  public Object peek() {
    if (isEmpty()) throw new NoSuchElementException();
    return elementData[front];
  }
  
  @Override
  //ให้แก้ method dequeue ของ ArrayQueue 
  //ให้ลดขนาดของarray เมื่อมีที่ว่างในqueue>75%
  public Object dequeue() {
    Object e = peek();
    elementData[front] = null;
    front = (front + 1) % elementData.length;
    size--;
    int blank = elementData.length - size ;
    if( blank > (elementData.length*3/4) ) {
        Object[] arr = new Object[size] ;
        int i = 0  ;
        for (Object elementData1 : elementData) {
            if (elementData1 != null) {
                arr[i] = elementData1;
                i++;
            }
        } 
        elementData = arr ;
        front = 0;
    } 
    return e ;
  } 
  
    public Object split() {
      int cap = size - (size *2 *1/4 );
      ArrayQueue b = new ArrayQueue(cap);
      Object a ;
      front =  front+ (size*1/4) ; 
      for(int i = 0 ; i <cap ; i++){   
          a  = dequeue(); //ดึงแล้วลบทิ้ง //elementData[]ถูกลบ
          b.enqueue(a);
      }
      System.out.println(Arrays.toString(elementData));
      return b ;
  }
    
    public void merge( ArrayQueue q2 ) {
        for( int i =0 ; i<=q2.size() ; i++ ) {
            Object e = q2.dequeue();
            enqueue(e);
        }
    }
    
    public void clear() {
        int cap = size();
        for( int i=0 ; i<cap ; i++ ) {
            dequeue();
        }
    }
    
    public void reverse() {
        Object[] rev = new Object[size] ;
        for(int i=size ; i>0 ; i-- ) {
            Object e = peek();
            rev[ i-1] = e ;
            dequeue();
        }
        for(Object e : rev ) {
            enqueue(e);
        }
    } 
    
    }
