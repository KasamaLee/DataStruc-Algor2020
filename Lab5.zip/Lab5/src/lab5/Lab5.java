package lab5;
import java.util.Arrays;

public class Lab5 {

    public static void main(String[] args) {
        // TODO code application logic here
        /*
        ArrayQueue a = new ArrayQueue(8);
        a.enqueue("a");
        a.enqueue("b");
        a.enqueue("c");
        a.enqueue("d");
        a.enqueue("e");
        a.enqueue("f");
        a.enqueue("g");
        a.enqueue("h");
        a.dequeue(); //a
        a.dequeue(); //b
        //a.dequeue();
        //System.out.println("คืนค่า = "+a.dequeue()); //g
        
        //ArrayQueue a2 = new ArrayQueue(2);
        //a2.enqueue("1");
        //a2.enqueue("2");
        //a.merge(a2); 
        //a.reverse();
        a.split();
        a.clear();
        */
        ArrayListQueue b = new ArrayListQueue(8);
        b.enqueue("a");
        b.enqueue("b");
        b.enqueue("c");
        b.enqueue("d");
        b.enqueue("e");
        b.enqueue("f");
        b.enqueue("g");
        b.enqueue("h");
        b.dequeue();
        b.dequeue();
        b.dequeue();
        b.split();

        /*
        ArrayListQueue b2 = new ArrayListQueue(3);
        b2.enqueue("1");
        b2.enqueue("2");
        b2.enqueue("3");
        b.merge(b2);
        b.clear();
        */
    }
    
}
