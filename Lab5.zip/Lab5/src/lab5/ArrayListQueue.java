package lab5;
import java.util.Arrays;
import java.util.NoSuchElementException;

public class ArrayListQueue implements Queue {
    
  private List list;
  
  public ArrayListQueue(int cap) {
    list = new ArrayList(cap);
  }
  @Override
  public boolean isEmpty() {
      return list.isEmpty();
  }
  @Override
  public int size() {
      return list.size();
  }
  
  @Override
  public void enqueue(Object e) {
      list.add(e);
  }
  
  @Override
  public Object peek() {
    if (isEmpty()) throw new NoSuchElementException();
    return list.get(0);
  }
  
  @Override
  public Object dequeue() {
    Object e = peek();
    list.remove(0);
    return e;
  }
  
  public Object split() {
       if (isEmpty()) throw new NoSuchElementException();
      int cap = size() - (size() *2 *1/4 );
      ArrayListQueue b = new ArrayListQueue(cap);
      
      int front =  size()*1/4 ; //2
      for(int i = 0 ; i < cap ; i++){     //0,1,2,3
          b.enqueue( list.get(front) );
          list.remove(front); //listจะเหลือหัวกับท้าย เอาตรงกลางออก
      }
      return b ;
  }
  
  public void merge(ArrayListQueue q2) {
      int cap = q2.size();
      for( int i=0 ; i<cap ; i++ ) {
          Object e = q2.dequeue();
          enqueue(e);
      }
  }
  
  public void clear() {
      int cap = size();
      for( int i=0 ; i<cap ; i++ ) {
          dequeue();
      } 
  }
  
  public void reverse() {
      Object[] rev = new Object[size()] ;
       int cap = size();
       for(int i=cap ; i>0 ; i-- ) {
            Object e = dequeue();
            rev[ i-1] = e ;
        }
       for(Object e : rev) {
           enqueue(e);
       }
  }
 
}
