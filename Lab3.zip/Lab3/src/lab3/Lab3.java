 
package lab3;

import java.util.Scanner;

public class Lab3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        Graph a = new Graph();
        System.out.println("Input:");
        String point ;
        do{ 
            System.out.print("Enter vertex: ");
            point = in.nextLine();  
            if(!point.equals("")){
            a.addVertex(point);
            }
        }
        while(!point.equals(""));

        System.out.print("\n");
        do{ 
            System.out.print("Enter edge: ");
            point = in.nextLine();  
            if(!point.equals("")){ 
                String[] part = point.split(",");
                a.addEdge(part[0], part[1]);
            }
        }
        while(!point.equals(""));
        
        System.out.println("--------\nOutput: ");
        System.out.println(a.toStr());
        System.out.println("Vertex a and b are adjacent: " + a.adjacent("a","b" ));
        System.out.println("Vertex a and c are adjacent: " + a.adjacent("a","c" ));
        System.out.println( "Graph contain vertex a: " + a.containVertex("a"));
        System.out.println(  "Graph contain vertex x: " + a.containVertex("x"));
        a.changeLabel("a", "x");
        System.out.println( "Graph contain vertex a: " + a.containVertex("a"));
        System.out.println( "Graph contain vertex x: " + a.containVertex("x"));
        System.out.println( a.toStr() );
    }
}
    

