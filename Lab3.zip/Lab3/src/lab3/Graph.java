/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab3;

/**
 *
 * @author imyourlullaby
 */
public class Graph {
    private ArrayList vertices; 
    
    public Graph() {
         vertices = new ArrayList(1);
    }
    
    public int size(){
        return vertices.size();
    }
    
    public void changeLabel(String a,String b){
        if(this.posOfVertexNamed(a)== -1){
            return;
        }
            Vertex x = (Vertex)vertices.get(this.posOfVertexNamed(a));
            if(x.equals(a)){
                x.changelable(b);}
        
    }
    public void addVertex(String lable){
        if(this.posOfVertexNamed(lable)!= -1){
            return;
        }
        Vertex x = new Vertex(lable);
        vertices.add(x);
    }
    public void addEdge(String vName, String uName){
        if(this.posOfVertexNamed(vName)== -1 || this.posOfVertexNamed(uName)== -1 ){
            return;
        }
            Vertex x = this.getVertex(vName);
            x.adjList.add(this.getVertex(uName));
        
    }
            
    private int posOfVertexNamed(String lable){
        for(int i = 0 ; i<vertices.size();i++){
            Vertex x = (Vertex)vertices.get(i);
            if(x.equals(lable)){return i;}
        }
        return -1;
        
    }
    public Boolean containVertex(String lable){
        return this.posOfVertexNamed(lable)!= -1;
    } 
    private Vertex getVertex(String lable){
            Vertex x = (Vertex) vertices.get(this.posOfVertexNamed(lable));
            return x ;
    }
    public Boolean adjacent(String a,String b){
          Vertex x = (Vertex) vertices.get(this.posOfVertexNamed(a));
          if(x.adjList.contains(this.getVertex(b))){
                return true  ;
          } return false;
        
    }
    public String toStr(){
        
        Vertex x = (Vertex)vertices.get(0);
        String ans = "There are "+this.size()+ " verties\nAnd edge as follows: "; 
        for(int i = 0 ; i< vertices.size();i++)
          {  x = (Vertex)vertices.get(i);
                for(int j = 1 ; j< x.adjList.size() ;j++){
                    if(i!=0||j!=1){ans+= ", ";}
                    Vertex y = (Vertex) x.adjList.get(j);
                    ans += "("+ x.adjList.get(0)+","+y.adjList.get(0)+")";
                    
                }

        }
        return ans ;
    }
    
    private static class Vertex{
        private String lable;
        private ArrayList adjList;
        
        public Vertex(String name){
            adjList = new ArrayList(1);
            adjList.add(name);
        }
        private Boolean equals(String name){
            return adjList.contains(name);
            
        }
        private void changelable(String name){
            System.out.println( "Change vertex: ("+adjList.get(0)+", "+name +")");
            adjList.set(0, name);

        }
    }
}
